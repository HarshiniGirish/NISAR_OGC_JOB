"""Target-specific package emitters."""
